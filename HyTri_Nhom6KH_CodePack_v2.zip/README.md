# HyTri-Selective: Phân loại lỗi CI đa lỗi với LLM mã nguồn mở cục bộ

Đề tài **Nhóm 6KH – Học phần IT5440** (Nguyên lý và Kỹ thuật Phân tích Chương trình, Đại học Bách Khoa Hà Nội).

## 1. Giới thiệu
Dự án đánh giá và hiệu chỉnh hệ thống phân loại lỗi CI đa lỗi **HyTri** khi thay thế API thương mại (`GPT-4o` + `text-embedding-3-small`) bằng mô hình mã nguồn mở chạy cục bộ (`Qwen2.5-Coder-7B-Instruct` / `DeepSeek-Coder-6.7B-Instruct` + `BAAI/bge-large-en-v1.5` / `intfloat/e5-large-v2`, chi phí API = `0 USD`), đồng thời đề xuất:
1. Vá 2 lỗi kỹ thuật trong gói mã nguồn gốc (`_call_openai` và thiếu khóa `diff_line`).
2. Chuẩn hóa **Min-Max không giám sát theo từng build** cho tín hiệu ngữ nghĩa (`S_semantic`) để khắc phục hiện tượng *anisotropy* của embedding mã nguồn mở.
3. Cơ chế điều phối lai có chọn lọc (**HyTri-Selective**): dùng độ tin cậy dấu vết động có sẵn (`conf_pdm >= 0.3` hoặc `conf_overlap >= 0.3`) để chỉ kích hoạt LLM cục bộ khi stack trace bị cụt (như `Bears`).

## 2. Cấu trúc thư mục
```text
├── hytri/                                 # Mã nguồn lõi HyTri (đã vá lỗi)
├── scripts/
│   ├── apply_hytri_patches.py             # Script vá tự động 3 file lõi trong hytri/
│   ├── export_dataset_split.py            # Cắt mẫu tách biệt (45 hoặc 195 builds) từ dữ liệu gốc
│   ├── check_cache.py                     # Kiểm tra chất lượng cache LLM (fallback, exact match)
│   └── run_rqs_clean.py                   # Chạy toàn bộ RQ1, RQ2, RQ3, Selective & Wilcoxon
├── notebooks/
│   ├── kaggle_run_llm_cache.ipynb         # Sinh cache Qwen-7B / DeepSeek-Coder trên Kaggle GPU
│   └── kaggle_reembed_alt_model.ipynb     # Thay embedding sang intfloat/e5-large-v2 (~1 phút)
├── data/
│   ├── pilot_45_builds.json               # Tập Pilot tách biệt (15 Validation + 30 Test)
│   └── llm_cache_qwen.json                # Cache phản hồi Qwen2.5-Coder-7B + bge-large
├── results/                               # Bảng số liệu CSV thực nghiệm
└── docs/                                  # Slide báo cáo & tài liệu nhóm
```

> **Lưu ý dữ liệu gốc:** Tập dữ liệu đầy đủ (~40 GB) của MFCI-Benchmark không được đẩy lên GitHub. File `data/pilot_45_builds.json` và `data/llm_cache_qwen.json` đủ để tái lập toàn bộ kết quả Báo cáo Lần 2 trên CPU trong ~5 giây. *(Nếu `llm_cache_qwen.json` > 50 MB và được lưu ngoài GitHub, tải từ link Google Drive của nhóm và đặt vào `data/llm_cache_qwen.json`.)*

## 3. Hướng dẫn cài đặt & tái lập nhanh kết quả Lần 2 (CPU ~5 giây)
Yêu cầu **Python 3.10+**.

```bash
# 1. Tạo môi trường ảo và cài đặt gói hytri
python -m venv .venv
# Windows:
.venv\Scripts\activate
# Linux/macOS:
# source .venv/bin/activate

pip install -e .

# 2. Áp dụng các bản vá trực tiếp vào mã nguồn hytri/
python scripts/apply_hytri_patches.py

# 3. Kiểm tra chất lượng cache đầu ra của Qwen2.5-Coder-7B
python scripts/check_cache.py --dataset data/pilot_45_builds.json --cache data/llm_cache_qwen.json

# 4. Chạy lại toàn bộ bảng RQ1, RQ2, RQ3 & kiểm định Wilcoxon (Pilot 45 builds)
python scripts/run_rqs_clean.py --dataset data/pilot_45_builds.json --cache data/llm_cache_qwen.json --baselines results/test_baselines_30.csv --out-prefix clean
```

## 4. Hướng dẫn chạy mở rộng (195 builds & đa mô hình)
```bash
# Bước 1: Cắt mẫu 195 builds (45 Validation + 150 Test, 0% trùng lặp) từ dữ liệu gốc
python scripts/export_dataset_split.py --n-test 50 --n-val 15 --out data/exp_195_builds.json

# Bước 2: Chạy 4 baselines không LLM trên 150 Test builds
python scripts/run_evaluation.py --num-builds 50 --seed 42 --output results/test_baselines_150.csv

# Bước 3: Upload data/exp_195_builds.json lên Kaggle và chạy notebooks/kaggle_run_llm_cache.ipynb
#         (Hỗ trợ cả Qwen/Qwen2.5-Coder-7B-Instruct và deepseek-ai/deepseek-coder-6.7b-instruct)

# Bước 4: Đánh giá trên CPU với file cache tải về từ Kaggle
python scripts/run_rqs_clean.py --dataset data/exp_195_builds.json --cache data/llm_cache_qwen_195.json --baselines results/test_baselines_150.csv --out-prefix exp195_qwen
```

## 5. Kết quả Pilot bước đầu (30 Test builds, 15 Validation builds tách biệt)

| Phương pháp | Overall ARI | NMI | B³ F1 | Defects4J | Bears (Stack cụt) | BugSwarm | Mean (s) |
| :--- | :---: | :---: | :---: | :---: | :---: | :---: | :---: |
| BuildSheriff (không LLM) | 0,618 | 0,759 | 0,841 | 0,603 | 0,540 | 0,709 | — |
| HyTri-NoLLM (Tĩnh + Động) | 0,687 | 0,783 | 0,834 | 0,746 | 0,563 | 0,753 | 0,09 |
| HyTri+Qwen (Mặc định) | 0,567 | 0,672 | 0,814 | 0,731 | 0,189 | 0,781 | 52,12 |
| HyTri+Qwen (Hiệu chỉnh đủ) | **0,703** | **0,810** | **0,860** | 0,722 | **0,607** | **0,781** | 52,12 |
| **HyTri-Selective (Đề xuất)** | **0,702** | **0,811** | **0,857** | **0,746** | **0,607** | 0,755 | **18,29** |
