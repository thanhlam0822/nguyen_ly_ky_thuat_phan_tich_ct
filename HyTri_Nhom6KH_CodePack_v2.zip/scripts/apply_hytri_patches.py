#!/usr/bin/env python3
"""
Safely apply Nhom 6KH's 3 core patches directly to the hytri/ package:
  1. hytri/llm/openai_client.py   : Add missing _call_openai() method called by HypothesisGenerator
  2. hytri/ensemble/pipeline.py   : Add missing "diff_line": 0.18 key in EnsembleConfig default weights
  3. hytri/similarity/semantic.py : Add optional unsupervised per-build Min-Max cosine calibration

Safe to run multiple times (idempotent) and creates .bak backups before modifying any file.
"""

from pathlib import Path
import re
import shutil

ROOT = Path(__file__).resolve().parent.parent


def backup_once(path: Path) -> None:
    bak = path.with_suffix(path.suffix + ".bak")
    if not bak.exists():
        shutil.copy2(path, bak)
        print(f"  [Backup] Created {bak.relative_to(ROOT)}")


def patch_openai_client() -> None:
    p = ROOT / "hytri" / "llm" / "openai_client.py"
    if not p.exists():
        print(f"[SKIP] {p} not found")
        return
    txt = p.read_text(encoding="utf-8")
    if "def _call_openai(" in txt:
        print("[OK] openai_client.py already has _call_openai()")
        return

    backup_once(p)
    method_code = """
    def _call_openai(
        self,
        prompt: str,
        system_prompt: str | None = None,
        temperature: float = 0.0,
        max_tokens: int = 1000,
    ) -> str:
        \"\"\"Compatibility wrapper expected by hytri.ensemble.hypothesis.HypothesisGenerator.\"\"\"
        messages = []
        if system_prompt:
            messages.append({"role": "system", "content": system_prompt})
        messages.append({"role": "user", "content": prompt})

        client = getattr(self, "client", None) or getattr(self, "_client", None)
        if client is None:
            raise RuntimeError("OpenAI client is not initialized")

        model = getattr(self, "model", None) or getattr(self, "chat_model", "gpt-4o-mini")
        resp = client.chat.completions.create(
            model=model,
            messages=messages,
            temperature=temperature,
            max_tokens=max_tokens,
        )
        return (resp.choices[0].message.content or "").strip()
"""
    lines = txt.splitlines(keepends=True)
    in_class = False
    insert_idx = len(lines)
    for i, ln in enumerate(lines):
        if ln.startswith("class OpenAIClient"):
            in_class = True
            continue
        if in_class and ln.strip() and not ln.startswith((" ", "\t", "#")):
            insert_idx = i
            break
    lines.insert(insert_idx, method_code + "\n")
    p.write_text("".join(lines), encoding="utf-8")
    print("[PATCHED] hytri/llm/openai_client.py -> added _call_openai()")


def patch_pipeline_diff_line() -> None:
    p = ROOT / "hytri" / "ensemble" / "pipeline.py"
    if not p.exists():
        print(f"[SKIP] {p} not found")
        return
    txt = p.read_text(encoding="utf-8")
    m = re.search(r"signal_weights\s*:.*?default_factory\s*=\s*lambda\s*:\s*\{([^}]+)\}", txt, re.DOTALL)
    if not m:
        print("[WARN] Could not locate EnsembleConfig signal_weights dict in pipeline.py; please verify manually.")
        return
    dict_body = m.group(1)
    if '"diff_line"' in dict_body or "'diff_line'" in dict_body:
        print("[OK] pipeline.py EnsembleConfig already contains 'diff_line'")
        return

    backup_once(p)
    new_body = re.sub(
        r'(["\']overlap["\']\s*:\s*[0-9.]+,?)',
        r'\1\n            "diff_line": 0.18,',
        dict_body,
        count=1,
    )
    if new_body == dict_body:
        new_body = dict_body.rstrip() + ', "diff_line": 0.18'
    new_txt = txt[: m.start(1)] + new_body + txt[m.end(1) :]
    p.write_text(new_txt, encoding="utf-8")
    print("[PATCHED] hytri/ensemble/pipeline.py -> added 'diff_line': 0.18 to EnsembleConfig")


def patch_semantic_minmax() -> None:
    p = ROOT / "hytri" / "similarity" / "semantic.py"
    if not p.exists():
        print(f"[SKIP] {p} not found")
        return
    txt = p.read_text(encoding="utf-8")
    if "calibration_mode" in txt:
        print("[OK] semantic.py already supports calibration_mode ('none' | 'minmax')")
        return

    target_init = "cache_normalizations: bool = True,"
    target_calc = "sim_matrix = (sim_matrix + 1) / 2"
    if target_init not in txt or target_calc not in txt:
        print("[WARN] semantic.py format differs from expected; skipping auto-patch.")
        return

    backup_once(p)
    txt = txt.replace(
        target_init,
        'cache_normalizations: bool = True,\n        calibration_mode: str = "minmax",',
        1,
    )
    txt = txt.replace(
        "self.cache_normalizations = cache_normalizations",
        "self.cache_normalizations = cache_normalizations\n        self.calibration_mode = calibration_mode",
        1,
    )
    minmax_block = """if self.calibration_mode == "minmax" and n > 1:
            # Unsupervised per-build Min-Max calibration to remove open-source embedding anisotropy
            off_diag = ~np.eye(n, dtype=bool)
            lo = float(np.min(sim_matrix[off_diag]))
            hi = float(np.max(sim_matrix[off_diag]))
            if hi - lo > 1e-6:
                sim_matrix = np.clip((sim_matrix - lo) / (hi - lo), 0.0, 1.0)
            else:
                sim_matrix = np.clip(sim_matrix, 0.0, 1.0)
        else:
            sim_matrix = (sim_matrix + 1) / 2"""
    txt = txt.replace(target_calc, minmax_block, 1)
    p.write_text(txt, encoding="utf-8")
    print("[PATCHED] hytri/similarity/semantic.py -> added calibration_mode ('minmax' | 'none')")


def main() -> None:
    print("Applying Nhom 6KH patches to hytri/ ...")
    patch_openai_client()
    patch_pipeline_diff_line()
    patch_semantic_minmax()
    print("Done.")


if __name__ == "__main__":
    main()
