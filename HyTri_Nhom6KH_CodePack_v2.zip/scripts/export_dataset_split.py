#!/usr/bin/env python3
"""
Export stratified, 0%-overlap (Test + Validation) dataset JSON from raw MFCI-Benchmark folders.

Usage examples:
  # Reproduce Pilot 45 builds (30 Test + 15 Validation):
  python scripts/export_dataset_split.py --n-test 10 --n-val 5 --out data/pilot_45_builds.json

  # Next-week Expansion: 195 builds (150 Test + 45 Validation):
  python scripts/export_dataset_split.py --n-test 50 --n-val 15 --out data/exp_195_builds.json
"""

import argparse
import json
import random
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
DATA_DIR = ROOT / "data"

SOURCE_CANDIDATES = [
    ("Defects4J-Real", ["defects4j_multifault_realistic", "defects4j_real", "defects4j"]),
    ("Bears-Real", ["bears_multifault_realistic", "bears_real", "bears"]),
    ("BugSwarm-Real", ["bugswarm_multifault_realistic", "bugswarm_real", "bugswarm"]),
]


def find_source_path(candidates: list[str]) -> Path:
    for name in candidates:
        for p in [DATA_DIR / name, DATA_DIR / f"{name}.jsonl", DATA_DIR / f"{name}.json"]:
            if p.exists():
                return p
    for name in candidates:
        hits = list(DATA_DIR.glob(f"*{name}*"))
        if hits:
            return hits[0]
    raise FileNotFoundError(
        f"Could not find dataset for {candidates} under {DATA_DIR}. "
        "Please make sure raw MFCI-Benchmark folders/files are placed in D:\\HyTri\\data\\."
    )


def load_builds_from_path(path: Path) -> list[dict]:
    builds = []
    if path.is_file():
        if path.suffix == ".jsonl":
            with open(path, "r", encoding="utf-8") as f:
                for line in f:
                    line = line.strip()
                    if line:
                        builds.append(json.loads(line))
        else:
            obj = json.loads(path.read_text(encoding="utf-8"))
            builds = obj if isinstance(obj, list) else obj.get("builds", [obj])
    elif path.is_dir():
        jsonl_files = sorted(path.glob("*.jsonl"))
        json_files = sorted(path.glob("*.json"))
        if jsonl_files:
            for jf in jsonl_files:
                with open(jf, "r", encoding="utf-8") as f:
                    for line in f:
                        line = line.strip()
                        if line:
                            builds.append(json.loads(line))
        elif json_files:
            for jf in json_files:
                obj = json.loads(jf.read_text(encoding="utf-8"))
                builds.extend(obj if isinstance(obj, list) else [obj])
        else:
            for jf in sorted(path.rglob("*.json*")):
                if jf.suffix == ".jsonl":
                    with open(jf, "r", encoding="utf-8") as f:
                        for line in f:
                            if line.strip():
                                builds.append(json.loads(line))
                elif jf.suffix == ".json":
                    obj = json.loads(jf.read_text(encoding="utf-8"))
                    builds.extend(obj if isinstance(obj, list) else [obj])
    return builds


def slim_build(b: dict, source_name: str, split_name: str) -> dict:
    raw_diffs = b.get("combined_file_diffs") or b.get("file_diffs") or {}
    slim_diffs = {k: (v[:4000] if isinstance(v, str) else "") for k, v in raw_diffs.items()}

    slim_failures = []
    for idx, fl in enumerate(b.get("failures", [])):
        slim_failures.append({
            "build_id": fl.get("build_id") or b.get("build_id", ""),
            "failure_id": fl.get("failure_id") or f"{b.get('build_id', 'build')}::failure_{idx}",
            "test_name": fl.get("test_name", ""),
            "exception_type": fl.get("exception_type", "Unknown"),
            "exception_message": (fl.get("exception_message") or "")[:1000],
            "stack_trace": (fl.get("stack_trace") or "")[:3000],
            "frames": (fl.get("frames") or [])[:25],
            "project": fl.get("project", b.get("project", "")),
            "ground_truth_bug": fl.get("ground_truth_bug"),
            "ground_truth": fl.get("ground_truth"),
            "bug_id": fl.get("bug_id"),
        })

    return {
        "build_id": b.get("build_id", ""),
        "source": source_name,
        "split": split_name,
        "combined_changed_files": b.get("combined_changed_files") or b.get("changed_files") or [],
        "combined_file_diffs": slim_diffs,
        "failures": slim_failures,
    }


def main() -> None:
    parser = argparse.ArgumentParser(description="Export stratified disjoint Test + Validation builds.")
    parser.add_argument("--n-test", type=int, default=50, help="Number of Test builds per source (default: 50 -> 150 total)")
    parser.add_argument("--n-val", type=int, default=15, help="Number of Validation builds per source (default: 15 -> 45 total)")
    parser.add_argument("--test-seed", type=int, default=42, help="Random seed for Test split (matches run_evaluation.py)")
    parser.add_argument("--val-seed", type=int, default=123, help="Random seed for Validation split")
    parser.add_argument("--out", type=str, default="data/exp_195_builds.json", help="Output JSON path")
    args = parser.parse_args()

    exported = []
    total_test_f, total_val_f = 0, 0

    for source_name, cands in SOURCE_CANDIDATES:
        src_path = find_source_path(cands)
        all_builds = load_builds_from_path(src_path)
        valid = [b for b in all_builds if b.get("failures") and len(b["failures"]) >= 2]
        valid.sort(key=lambda x: str(x.get("build_id", "")))

        if len(valid) < args.n_test + args.n_val:
            raise ValueError(
                f"{source_name}: requested {args.n_test} test + {args.n_val} val, "
                f"but only {len(valid)} valid builds found in {src_path}."
            )

        rng_test = random.Random(args.test_seed)
        test_builds = rng_test.sample(valid, args.n_test)
        test_ids = {b.get("build_id") for b in test_builds}

        remaining = [b for b in valid if b.get("build_id") not in test_ids]
        rng_val = random.Random(args.val_seed)
        val_builds = rng_val.sample(remaining, args.n_val)

        val_ids = {b.get("build_id") for b in val_builds}
        assert len(test_ids & val_ids) == 0, "Overlap detected between Test and Validation!"

        for b in test_builds:
            sb = slim_build(b, source_name, "test")
            exported.append(sb)
            total_test_f += len(sb["failures"])
        for b in val_builds:
            sb = slim_build(b, source_name, "tuning")
            exported.append(sb)
            total_val_f += len(sb["failures"])

        print(
            f"[OK] {source_name:<15} | available={len(valid):3d} | "
            f"test={len(test_builds):2d} | validation={len(val_builds):2d} | overlap=0"
        )

    out_path = ROOT / args.out
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(json.dumps(exported, ensure_ascii=False), encoding="utf-8")
    size_mb = out_path.stat().st_size / (1024 * 1024)
    print(
        f"\nSaved {len(exported)} builds ({args.n_test*3} Test / {total_test_f} failures + "
        f"{args.n_val*3} Validation / {total_val_f} failures) -> {out_path} ({size_mb:.2f} MB)"
    )


if __name__ == "__main__":
    main()
