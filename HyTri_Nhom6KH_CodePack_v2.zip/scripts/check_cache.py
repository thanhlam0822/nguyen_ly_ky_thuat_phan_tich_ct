#!/usr/bin/env python3
"""Verify completeness and JSON-parse quality of any LLM cache JSON."""

import argparse
import json
from pathlib import Path
import numpy as np

ROOT = Path(__file__).resolve().parent.parent


def main() -> None:
    parser = argparse.ArgumentParser(description="Verify LLM cache completeness and parse quality.")
    parser.add_argument("--dataset", type=str, default="data/pilot_45_builds.json")
    parser.add_argument("--cache", type=str, default="data/llm_cache_qwen.json")
    args = parser.parse_args()

    builds = json.loads((ROOT / args.dataset).read_text(encoding="utf-8"))
    cache = json.loads((ROOT / args.cache).read_text(encoding="utf-8"))

    meta = cache.get("meta", {})
    if meta:
        print(f"Cache metadata: {meta}")

    print(f"Builds in dataset          : {len(builds)}")
    print(f"Builds in cache[hypotheses]: {len(cache.get('hypotheses', {}))}")
    print(f"Unique normalizations      : {len(cache.get('normalizations', {}))}")
    print(f"Unique embeddings          : {len(cache.get('embeddings', {}))}")

    norm_total = len(cache.get("normalizations", {}))
    norm_fb = sum(
        1 for v in cache.get("normalizations", {}).values()
        if "@unknown ->" in (v.get("normalized_signature") or "")
    )
    print(f"\n[S_semantic] Normalization fallback: {norm_fb}/{norm_total} ({norm_fb/max(norm_total,1):.1%})")

    hyp_total = hyp_fb = hyp_has_file = hyp_exact_match = 0
    for b in builds:
        bid = b["build_id"]
        changed = set(b.get("combined_changed_files") or [])
        for h in cache.get("hypotheses", {}).get(bid, []):
            hyp_total += 1
            mech = h.get("mechanism") or ""
            if h.get("category") == "unknown" and mech.startswith("Failure in ") and h.get("confidence") in (0.1, 0.3):
                hyp_fb += 1
            sc = h.get("suspected_change")
            if sc and str(sc).lower() != "null":
                hyp_has_file += 1
                if sc in changed:
                    hyp_exact_match += 1

    print(f"[S_hyp] Total hypotheses           : {hyp_total}")
    print(f"[S_hyp] Fallback (parse/truncated) : {hyp_fb}/{hyp_total} ({hyp_fb/max(hyp_total,1):.1%})")
    print(f"[S_hyp] Non-null suspected_change  : {hyp_has_file}/{hyp_total} ({hyp_has_file/max(hyp_total,1):.1%})")
    print(f"[S_hyp] Exact match changed_files  : {hyp_exact_match}/{hyp_total} ({hyp_exact_match/max(hyp_total,1):.1%})")

    timings = cache.get("build_timings", {})
    if timings:
        times = [v["llm_total_sec"] for v in timings.values() if "llm_total_sec" in v]
        print(f"\n[Timing] Mean: {np.mean(times):.2f}s/build | Median: {np.median(times):.2f}s/build | Total: {np.sum(times)/60:.1f} min")


if __name__ == "__main__":
    main()
